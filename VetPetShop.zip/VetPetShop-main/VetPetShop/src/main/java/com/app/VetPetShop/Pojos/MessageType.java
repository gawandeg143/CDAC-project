package com.app.VetPetShop.Pojos;

public enum MessageType {

	CHAT, JOIN, LEAVE
	
}

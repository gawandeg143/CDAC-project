package com.app.VetPetShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetPetShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
